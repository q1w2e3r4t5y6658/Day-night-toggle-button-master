## 昼夜切换按钮-精简版

- 基本上和白天黑夜切换按钮3.0效果差不多 ~~（除了没有云朵动画）~~ ，已增加简单的云朵动画

## 预览

- [Codepen](https://codepen.io/yl2023/pen/eYXVKbX)

## 博客引用文档

- [好看的昼夜切换按钮](https://www.naokuo.top/posts/1c3b759a)

## 更新

- 修复 IOS 端星星为黑色的问题
- 优化星星锯齿问题